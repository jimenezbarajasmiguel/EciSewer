def cargar_proyecto(ruta, proyecto):
    project = QgsProject.instance() 
    project.read(os.path.join(ruta,proyecto))
    iface.mainWindow().setWindowTitle("Proyecto alcantarillado - " + proyecto )
    return project
    
def nuevo_proyecto(ruta, proyecto): 
    project = QgsProject.instance() 
    project.read(os.path.join(ruta,proyecto))
    iface.mainWindow().setWindowTitle("Proyecto alcantarillado - " + proyecto )
    # Copiar archivos base a carpeta seleccionada
    return project    
    
def cargar_capa_raster(ruta, archivo):
    capa = iface.addRasterLayer(os.path.join(ruta,archivo), archivo[0:len(archivo)-4])
    if not capa: 
        print("Layer failed to load!")
    return capa
    
def listar_capas():
    l = [layer.name() for layer in QgsProject.instance().mapLayers().values()]
    layers_list = []
    for l in QgsProject.instance().mapLayers().values(): 
        layers_list.append(l.name())
    return layers_list
    
def crear_barra_progreso(final):
    progressMessageBar = iface.messageBar().createMessage("Ejecución en progreso:")
    progress = QProgressBar()
    progress.setMaximum(final)
    progress.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
    progressMessageBar.layout().addWidget(progress)
    iface.messageBar().pushWidget(progressMessageBar, Qgis.Info)
    progress.setVisible(True)
    return progress
    
def actualiza_barra_progreso(progress, valor, final):
    progress.setValue(valor)
    iface.mapCanvas().refresh()
    iface.mapCanvas().waitWhileRendering()
    if valor >= final: 
        progress.setVisible(False)
        iface.messageBar().pushMessage("Informacion:", " Proceso completado", Qgis.Info, 5) #Info Warning Critical Success    

def validar_capa_raster(capa_raster):
    valido = True # 
    if capa_raster.renderer().type() == 2: 
        valido = False
    if capa_raster.bandCount() >=2: 
        valido = False
    return valido

def obtener_cota(capa_raster, x, y):
    val, res = capa_raster.dataProvider().sample(QgsPointXY(x, y), 1)
    if val == 1: 
        return(res)
    else:
        return(6666)

def obtener_atributos_geometricos(geom):
    if geom.type() == QgsWkbTypes.PointGeometry:
        if not geom.isMultipart():
            pt = geom.asPoint()
            attr1 = pt.x(); attr2 = pt.y()
        else:
            pt = geom.asMultiPoint()
            attr1 = pt[0].x(); attr2 = pt[0].y()
    else:
        measure = QgsDistanceArea()
        if geom.type() == QgsWkbTypes.PolygonGeometry:
            attr1 = measure.measurePerimeter(geom)
            attr2 = measure.measureArea(geom)
        else:
            attr1 = measure.measureLength(geom)
            attr2 = None
    return (attr1, attr2)

def crear_canvas(layer):
    canvas = QgsMapCanvas()
    canvas.setExtent(layer.extent())
    canvas.setLayers([layer])
    canvas.show()
    return canvas

def actualizar_proyecto():
    iface.messageBar().clearWidgets()
    iface.mapCanvas().setCanvasColor(Qt.white)
    iface.mapCanvas().refresh()  
