## Bibliotecas requeridas en la ejecucion del codigo
#from .utilitarios import *
from qgis.core import *#QgsVectorLayer, QgsProject, Qgis, QgsPointXY, QgsGeometryUtils, QgsCoordinateReferenceSystem, QgsGeometry, QgsPoint, QgsDistanceArea, QgsFeature, QgsField, QgsWkbTypes, QgsMapLayerProxyModel, QgsPalLayerSettings
from qgis.utils import iface
from PyQt5.QtWidgets import QMessageBox
from qgis.gui import QgsMapCanvas, QgsMapLayerComboBox
from qgis.PyQt.QtGui import *#QIcon, QFont, QColor
from PyQt5.QtWidgets import QProgressBar
from PyQt5.QtCore import Qt, QVariant
from PyQt5.QtWidgets import QAction
from PyQt5 import uic
import wx
import os
import math
import time
import numpy as np
import pandas as pd
import math
from scipy.optimize import root

plugin_path = os.path.dirname(__file__) 
files_path = ''
DialogBase, DialogType = uic.loadUiType(os.path.join(plugin_path, 'formulario.ui'))
escala=5.0

## Funciones comunes para la manipulacion de QGIS
def crear_barra_progreso(final):
    progressMessageBar = iface.messageBar().createMessage("Ejecución en progreso:")
    progress = QProgressBar()
    progress.setMaximum(final)
    progress.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
    progressMessageBar.layout().addWidget(progress)
    iface.messageBar().pushWidget(progressMessageBar, Qgis.Info)
    progress.setVisible(True)
    return progress

def actualiza_barra_progreso(progress, valor, final):
    progress.setValue(valor)
    iface.mapCanvas().refresh()
    iface.mapCanvas().waitWhileRendering()
    if valor >= final: 
        progress.setVisible(False)
        iface.messageBar().pushMessage("Informacion:", " Proceso completado", Qgis.Info, 5) #Info Warning Critical Success  

def crear_canvas(layer):
    canvas = QgsMapCanvas()
    canvas.setExtent(layer.extent())
    canvas.setLayers([layer])
    canvas.show()
    return canvas

## Funciones comunes para el calculo de redes tuberias

# Calculo del angulo de deflexion
def deflexion(x1,y1,x2,y2,x3,y3):
    return 180-math.degrees(math.pi
            -abs(math.atan(((y2-y1)/(x2-x1)-(y3-y1)/(x3-x1))/(1+((y2-y1)/(x2-x1)*(y3-y1)/(x3-x1)))))
            -abs(math.atan(((y2-y3)/(x2-x3)-(y1-y3)/(x1-x3))/(1+((y2-y3)/(x2-x3)*(y1-y3)/(x1-x3))))))

# Calculo del angulo de la tuberia que cumple los requerimientos minimos
def func(x): 
    return Q-(1/n)*((x-np.sin(x))*d**2/8)*(d*(1-np.sin(x)/x)/4)**(2/3)*(tao/(g*rho*(d*(1-np.sin(x)/x)/4)))**(1/2)    

# Calculo del angulo de la tuberia    
def func2(x): 
    return Q-(1/n)*((x-np.sin(x))*d**2/8)*(d*(1-np.sin(x)/x)/4)**(2/3)*S **(1/2)

# Calculo del angulo critico de la tuberia
def func3(x): 
    return Q/g**0.5-2**0.5/32*(x-np.sin(x))**1.5*d**2.5/(np.sin(x/2))**0.5

## Carga de datos - Carga la informacion de corridas previas

def carga_datos_existentes():
    global df, tubos, setup, pozos
    df=pd.read_csv(os.path.join(files_path, 'red_calculada.csv')) 
    tubos=pd.read_csv(os.path.join(files_path, 'tuberias.csv'))
    setup=pd.read_csv(os.path.join(files_path, 'setup.csv'))
    pozos=pd.read_csv(os.path.join(files_path, 'pozos.csv'))

## Carga de datos - Carga la informacion de topologia de la red, caracteristicas de las tuberias y costos asociados

def carga_datos():
# La instrucción global habilita el acceso de la variable dentro de la funciones. 
# Requerido para el uso de algunas funciones como por ejemplo scipy.optimize en func2 (Calculo del angulo de la tuberia) 
    global df, tubos, setup, c_escorrentia, C1, C2, d_disposicion, d_minimo, d_minimo_AALL, d_minimo_AASS
    global d_pz_min, delta_S, dot, ent_0_3, ent_3_48, ent_48_72, ent_72, exc_0_2, exc_2_5, exc_5_7, exc_7
    global F, fmQ, fR, fr_cr, fr_sc, g, hL_minimo, mat_are, mat_cama, mat_rec, mat_retiro, mat_sel, pob
    global Q_minimo, Qce, Qinf, Qotros, rec_min, rho, sobrependiente, tc_entrada, tipo_red, v_ini_asumida, X0,files_path
## Carga informacion en dataframes
# Obtiene la topologia de la red y su informacion geometrica del trazado en planta
    df=pd.read_csv(os.path.join(files_path, 'red.csv')) 
# Obtiene la informacion asociada a la tuberia de acuerdo a su diametro como
# diamtro interno y externo, rugosidad, ancho de zanja, costos y otros.
    tubos=pd.read_csv(os.path.join(files_path, 'tuberias.csv'))
# Obtiene informacion asociada al tipo de red (Pluvial o sanitaria), restricciones y condiciones de frontera,   
# costos de materiales, e informacion general de restricciones
    setup=pd.read_csv(os.path.join(files_path, 'setup.csv'))

## Carga de informacion comundiametro interno, externo
    tipo_red=setup['tipo_red'][0]
    g=float(setup['g'])
    rho=float(setup['rho'])
    fr_sc=float(setup['fr_sc'])
    fr_cr=float(setup['fr_cr'])
    delta_S=float(setup['delta_S'])
    d_pz_min=float(setup['d_pz_min'])
    v_ini_asumida=float(setup['v_ini_asumida'])
    rec_min=float(setup['rec_min'])
    Q_minimo=float(setup['Q_minimo'])
# Perdidas minimas en el colector: RAS artículo 137 - 0.02m
    hL_minimo=float(setup['hL_minimo']) 
    
## Informacion de costos de materiales, entibados y excavaciones
# Altura base granular de cama
    mat_cama=float(setup['mat_cama']) 
# Excavación En Zanja a máquina en material común h <2 m (M3)    
    exc_0_2=float(setup['exc_0_2'])
# Excavación En Zanja a máquina en material común 2<= h<=5 m (M3)    
    exc_2_5=float(setup['exc_2_5'])
# Excavación En Zanja a máquina en material común 5<h<=7 m (M3)    
    exc_5_7=float(setup['exc_5_7'])
# Excavación En Zanja a máquina en material común h > 7 m (M3)    
    exc_7=float(setup['exc_7'])
# Entibado continuo en cajones de acero H<=3,00 M (M2)    
    ent_0_3=float(setup['ent_0_3'])
# Entibado deslizante 3,00<H<=4,80 M (M2)    
    ent_3_48=float(setup['ent_3_48'])
# Entibado deslizante 4,80<H<=7,20 M (M2)   
    ent_48_72=float(setup['ent_48_72'])
# Entibado deslizante H>7,20 M (M2)   
    ent_72=float(setup['ent_72'])
# Suministro, transporte e instalación Recebo (M3)   
    mat_rec=float(setup['mat_rec'])
# Suministro, transporte e instalación material  excavación (M3)    
    mat_sel=float(setup['mat_sel'])
# Suministro, transporte e instalación de Arena de Peña (M3)    
    mat_are=float(setup['mat_are'])
# Retiro y disposic. materiales sobrantes excav y demol (M3.km)    
    mat_retiro=float(setup['mat_retiro'])
# Distancia al sitio de disposic de materiales sobrantes y de excavacion (km)    
    d_disposicion=float(setup['d_disposicion'])
    
## Informacion para diseño de tuberia pluvial
# Informacion hidrologica (idf)
    C1=float(setup['C1'])
    X0=float(setup['X0'])
    C2=float(setup['C2'])
# Diametro minimo pluvial
    d_minimo_AALL=float(setup['d_minimo_AALL'])
# Tiempo concentracion entrada    
    tc_entrada=float(setup['tc_entrada'])
# Coeficiente escorrentia    
    c_escorrentia=float(setup['c_escorrentia'])
    
## Informacion para diseño de tuberia sanitaria       
# Diametro minimo sanitario
    d_minimo_AASS=float(setup['d_minimo_AASS'])
# Densidad Población Futura (hab/ha)    
    pob=float(setup['pob']) 
# Dotación neta futura (l/hab/día)    
    dot=float(setup['dot']) 
# Factor de Retorno    
    fR=float(setup['fR']) 
# Factor Mayoración Caudal    
    fmQ=float(setup['fmQ']) 
# Tasa Conexiones Erradas (lps/ha)    
    Qce=float(setup['Qce']) 
# Tasa Infiltración (lps/ha)    
    Qinf=float(setup['Qinf']) 
# Caudal de aguas residuales comerciales y/o industriales (lps/ha)    
    Qotros=float(setup['Qotros']) 
# Factor de mayoración que para calcular el caudal máximo horario con base en el caudal medio diario    
    F=float(setup['F'])

## Inicializa variables
    d_minimo=d_minimo_AASS
    sobrependiente=0.0
    df['a_aflu']=0.0
    df['a_tot']=df['a_tramo']
    df['x_sig']=0.0
    df['y_sig']=0.0
    df['S_ras']=0.0
    df['L_XY']=0.0
    df['L']=0.0
    df['absc']=0.0
    df['deflex']=0.0
    df['Tc_tramo']=0.0
    df['Tc_aflu']=0.0
    df['Tc_tot']=tc_entrada
    df['I']=0.0
    df['C']=c_escorrentia
    df['Q_AALL']=0.0
    df['poblac']=0.0
    df['Qd']=0.0
    df['QMH']=0.0
    df['QCE']=0.0
    df['QINF']=0.0
    df['Qotros']=0.0
    df['Q_AASS']=0.0
    df['Q_propio']=0.0
    df['Q']=0.0
    df['S']=0.0
    df['S_min']=0.0
    df['d']=d_minimo_AASS
    df['n']=0.010
    df['Qo']=0.0
    df['Y_d']=0.0
    df['ang']=0.0
    df['A']=0.0
    df['P']=0.0
    df['T']=0.0
    df['V']=v_ini_asumida
    df['Y']=0.0
    df['Dh']=0.0
    df['R']=0.0
    df['tao']=0.0
    df['F']=0.0
    df['Hv']=0.0
    df['EE']=0.0
    df['ang_cr']=0.0
    df['Yc']=0.0
    df['Vc']=0.0
    df['EEc']=0.0
    df['d_pz_ini']=d_pz_min
    df['d_pz_fin']=d_pz_min
    df['pz_ini_bat'] = 1000000.0
    df['pz_fin_bat'] = 1000000.0
    df['r_curv']=0.0
    df['rc_fi']=0.0
    df['c_caida']=0.0
    df['k']=0.05
    df['hL']=0.0
    df['cla_ini']=0.0
    df['cla_fin']=0.0
    df['bat_ini']=0.0
    df['bat_fin']=0.0
    df['obg_ini']=rec_min
    df['obg_fin']=rec_min
    df['obg_sig']=rec_min
    df['rec_ini']=rec_min
    df['rec_fin']=rec_min
    df['d_obg']=d_minimo_AASS
    df['d_ext']=0.0
    df['h_barra']=0.0
    df['L_XY_tubo']=0.0
    df['sa_zanja']=0.0
    df['vol_exc']=0.0
    df['valor_ml']=0.0
    df['valor_insta']=0.0
    df['costo_tub']=0.0
    df['costo_mat']=0.0
    df['costo']=1000000000000
    df['fc_CRA']=0.0
    df['fc_prop']=0.0
    df=df.replace(np.nan, 0.0)
    
## Calculos preliminares - Abscisas, deflexiones, caudales iniciales
def inicializar(): 
## Calculos requeridos para la iteracion cero    
# Alias de la tuberia
    df['idd']=(df['pz_ini'].map(str)+'_'+df['pz_fin'].map(str))
# Longitud en el plano horizontal entre pozos
    df['L_XY']=((df['x_fin']-df['x_ini'])**2+(df['y_fin']-df['y_ini'])**2)**0.5
# Pendiente del terreno    
    df['S_ras']=(df['z_ini']-df['z_fin'])/df['L_XY'] 
# Valor inicial para el calculo del abscisado
    df['absc']=df['L_XY']

## Coordenadas siguiente pozo - Rerquerido para el calculo del angulo de deflexion
    for i, row in df.iterrows():
        try: 
            df.at[i,'x_sig']=df.loc[np.where((df['pz_ini']==df.at[i,'pz_fin']))]['x_fin'].max()
            df.at[i,'y_sig']=df.loc[np.where((df['pz_ini']==df.at[i,'pz_fin']))]['y_fin'].max()
        except: 
            pass 

## Abscisa punto final
        try: 
            if df.at[i,'red']==df.at[i-1,'red']:
                df.at[i,'absc']=df.at[i-1,'absc']+df.at[i,'L_XY']
        except: 
            pass  

## Calculo del angulo de deflexion    
        try: 
            df.at[i,'deflex']=deflexion(df.at[i,'x_ini'],df.at[i,'y_ini'],df.at[i,'x_fin'],
                                        df.at[i,'y_fin'],df.at[i,'x_sig'],df.at[i,'y_sig'])
        except: 
            pass 
        
## Area aferente predecesores y Area aferente acumulada
        df.at[i,'a_aflu']=df.loc[np.where((df['pz_fin']==df.at[i,'pz_ini']) 
                            & (df['red']!=df.at[i,'red']))]['a_tot'].sum()
        try:
            if df.at[i,'red']==df.at[i-1,'red']:
                df.at[i,'a_tot']=df.at[i-1,'a_tot']+df.at[i,'a_tramo']+df.at[i,'a_aflu']
            else:
                df.at[i,'a_tot']=df.at[i,'a_tramo']
        except: pass

## Calculos para el caudal de diseño para tuberías sanitarias
    if tipo_red=='AASS':
        df['poblac']=np.round(pob*df['a_tot'],0)
        df['Qd']=df['poblac']*dot*fR*fmQ/86400
        df['QMH']=df['Qd']*F
        df['QCE']=df['a_tot']*Qce
        df['QINF']=df['a_tot']*Qinf
        df['Qotros']=df['a_tot']*Qotros
# Se requiere un caudal minimo de 1.5lps
        df['Q_AASS']=Q_minimo
        df['Q_AASS']=np.maximum(df['Q_AASS'],(df['QMH']+df['QCE']+df['QINF']+df['Qotros']))        
        df['Q']=df['Q_AASS']
        d_minimo=d_minimo_AASS
# Inicializa el diametro minimo
        df['d']=d_minimo  

## Calculos para el caudal de diseño para tuberías pluviales
    else:
# Cambia el factor tirante/diametro maximo
        tubos['y_D']=0.93
# Calculos iniciales hidrologicos    
        df['I']=2.78*C1/(df['Tc_tot']+X0)**C2
        df['Q_AALL']=df['C']*df['I']*df['a_tot']
        df['Q']=df['Q_AALL']
# Tiempo de concentracion
        tiempo_concentracion()
        d_minimo=d_minimo_AALL
# Inicializa el diametro minimo
        df['d']=d_minimo    
    

## Calculo del caudal de acuerdo al Tiempo de concentracion - Usado solamente para tuberias pluviales   
# Recalcula el tiempo de concentracion por cambio de diametro del tubo o del pozo
# El tc depende de la logitud de la tuberia y su pendiente        
def recalcular(): 
    if tipo_red=='AALL':
        df['I']=2.78*C1/(df['Tc_tot']+X0)**C2 
        df['Q_AALL']=df['C']*df['I']*df['a_tot'] 
        df['Q']=df['Q_AALL']
        tiempo_concentracion()
        
        
## Calculo del Tiempo de concentracion - Usado solamente para tuberias pluviales   
def tiempo_concentracion(): 
# La primera entrada a esta funcion asume una velocidad del fluido de 1.5m/s
    if tipo_red=='AALL':
        df['Tc_tramo']=df['L_XY']/df['V']/60
        df['Tc_tot']=df['Tc_tramo']+df['Tc_tot']
# Tiempo_concentracion acumulado
        for i, row in df.iterrows():
            try: 
                if df.at[i,'red']==df.at[i-1,'red']:
                    df.at[i,'Tc_tot']=df.at[i-1,'Tc_tot']+df.at[i,'Tc_tramo']
                if  df.at[i,'Tc_tot']<df.at[i,'Tc_aflu']:
                    df.at[i,'Tc_tot']=df.at[i,'Tc_aflu']+df.at[i,'Tc_tramo']
            except: 
                pass  
            df.at[i,'Tc_aflu']=df.loc[np.where((df['pz_fin']==df.at[i,'pz_ini']) 
                                             & (df['red']!=df.at[i,'red']))]['Tc_tot'].max()
            df['Tc_aflu'] = df['Tc_aflu'].fillna(0)
    

## Calculos requeridos por cada tuberia de la red
def calcular_linea1(i,df_linea):
    global S 
    global sobrependiente

# Caracteristicas del pozo - Radio de curvatura
    df_linea.at[i,'r_curv']=(df_linea.at[i,'d_pz_fin']/2)/(np.tan(df_linea.at[i,'deflex']/180)/2)
    df_linea.at[i,'rc_fi']=df_linea.at[i,'r_curv']/df_linea.at[i,'d']    

# Longitud real de la tuberia - Se requiere recalcular por cambio de diametro de pozo    
    df_linea.at[i,'L']=((df_linea.at[i,'L_XY']-df_linea.at[i,'d_pz_ini']/2-df_linea.at[i,'d_pz_fin']/2)**2+
                        (df_linea.at[i,'z_fin']-df_linea.at[i,'z_ini'])**2)**0.5 # 
    
# Cotas obligadas - Garantiza que la profundidad del recubrimiento tenga en cuenta tuberias afluentes 
    df_linea.at[i,'rec_ini']=max(df_linea.at[i,'int_ini'],df_linea.at[i,'obg_ini'])

# Las perdidas en colector Obliga un recubrimiento del tramo siguiente    
    df_linea.at[i,'rec_fin']=max(df_linea.at[i,'int_fin'],df_linea.at[i,'obg_fin']) 

# Pendiente del tramo a partir de condiciones de frontera (scipy.optimize y topografia)
# La variable sobrependiente se incluye en caso de requerir cambiar el numero de Froude del tramo evaluado
    df_linea.at[i,'S']=max(df_linea.at[i,'S_min'],sobrependiente+((df_linea.at[i,'z_ini']
                          -df_linea.at[i,'rec_ini'])-(df_linea.at[i,'z_fin']-df_linea.at[i,'rec_fin']))
                           /(df_linea.at[i,'L_XY']-df_linea.at[i,'d_pz_ini']/2-df_linea.at[i,'d_pz_ini']/2))
    S=df_linea.at[i,'S']
    
# Caracteristicas hidraulicas del tubo
    df_linea.at[i,'Qo']=(1/df_linea.at[i,'n'])*((math.pi*df_linea.at[i,'d']**2/4)/
            (math.pi*df_linea.at[i,'d']))**(2/3)*(math.pi*df_linea.at[i,'d']**2/4)*(df_linea.at[i,'S']/1)**0.5*1000
    df_linea.at[i,'ang']=float(root(func2,math.pi).x)
    df_linea.at[i,'Y']=(1-np.cos(df_linea.at[i,'ang']/2))*df_linea.at[i,'d']/2
    df_linea.at[i,'Y_d']=df_linea.at[i,'Y']/df_linea.at[i,'d']
    df_linea.at[i,'R']=df_linea.at[i,'d']/4*(1-np.sin(df_linea.at[i,'ang'])/df_linea.at[i,'ang'])
    df_linea.at[i,'tao']=rho*g*df_linea.at[i,'S']*df_linea.at[i,'R']
    df_linea.at[i,'V']=df_linea.at[i,'R']**(2/3)*df_linea.at[i,'S']**0.5/df_linea.at[i,'n']
    df_linea.at[i,'A']=df_linea.at[i,'d']**2/8*(df_linea.at[i,'ang']-np.sin(df_linea.at[i,'ang']))
    df_linea.at[i,'P']=df_linea.at[i,'ang']*df_linea.at[i,'d']/2
    df_linea.at[i,'T']=df_linea.at[i,'d']*np.cos(np.arcsin((df_linea.at[i,'Y']-df_linea.at[i,'d']/2)/
                        (df_linea.at[i,'d']/2)))
    df_linea.at[i,'Dh']=df_linea.at[i,'A']/df_linea.at[i,'T']
    df_linea.at[i,'F']=df_linea.at[i,'V']/(g*df_linea.at[i,'Dh'])**0.5                        
    df_linea.at[i,'Hv']=df_linea.at[i,'V']**2/(2*g)
    df_linea.at[i,'EE']=df_linea.at[i,'Y']+df_linea.at[i,'Hv']
    
# Regimen critico
    df_linea.at[i,'ang_cr']=float(root(func3,math.pi).x)
    df_linea.at[i,'Yc']=(1-np.cos(df_linea.at[i,'ang_cr']/2))*df_linea.at[i,'d']/2
    df_linea.at[i,'Vc']=(df_linea.at[i,'Q']/1000)/df_linea.at[i,'d']**2/8*(df_linea.at[i,'ang_cr']-
                        np.sin(df_linea.at[i,'ang_cr']))
    df_linea.at[i,'EEc']=df_linea.at[i,'Yc']+df_linea.at[i,'Vc']**2/(2*g)    
    
# Perdidas en el colector
    if df_linea.at[i,'F']<1:
        if df_linea.at[i,'rc_fi']>3:
            df_linea.at[i,'k']=0.05
        elif df_linea.at[i,'rc_fi']>1.5 and df_linea.at[i,'rc_fi']<=3:
            df_linea.at[i,'k']=0.20
        else:
            df_linea.at[i,'k']=0.40
    else:
        if df_linea.at[i,'rc_fi']>10:
            df_linea.at[i,'k']=0.05
        elif df_linea.at[i,'rc_fi']>8 and df_linea.at[i,'rc_fi']<=10:
            df_linea.at[i,'k']=0.20
        else:
            df_linea.at[i,'k']=0.40        
    df_linea.at[i,'hL']=max(df_linea.at[i,'k']*df_linea.at[i,'Hv'], hL_minimo)

# Perfil de alcantarillado (m.s.n.m)
    df_linea.at[i,'cla_ini']=df_linea.at[i,'z_ini']-df_linea.at[i,'rec_ini']
    df_linea.at[i,'cla_fin']=df_linea.at[i,'cla_ini']-df_linea.at[i,'L']*df_linea.at[i,'S']
    df_linea.at[i,'bat_ini']=df_linea.at[i,'cla_ini']-df_linea.at[i,'d']
    df_linea.at[i,'bat_fin']=df_linea.at[i,'cla_fin']-df_linea.at[i,'d']

# Cota obligada siguiente clave    
    df_linea.at[i,'obg_sig']=df_linea.at[i,'z_fin']-df_linea.at[i,'cla_fin']+df_linea.at[i,'hL'] 

    
## Costos

# Volumen de la excavacion. Seccion formada en perfil por un trapecio escaleno
    df_linea.at[i,'h_barra']=(df_linea.at[i,'rec_ini']+df_linea.at[i,'d_ext']+
                                mat_cama+df_linea.at[i,'rec_fin']+df_linea.at[i,'d_ext']+mat_cama)/2
    df_linea.at[i,'L_XY_tubo']=df_linea.at[i,'L_XY']-df_linea.at[i,'d_pz_fin']/2-df_linea.at[i,'d_pz_ini']/2
    df_linea.at[i,'vol_exc']=df_linea.at[i,'L_XY_tubo']*df_linea.at[i,'h_barra']*(df_linea.at[i,'d_ext']+
                                df_linea.at[i,'sa_zanja'])
    
# Costos asociados con la tuberia
    df_linea.at[i,'costo_tub']=df_linea.at[i,'costo']=df_linea.at[i,'L']*(df_linea.at[i,'valor_ml']+
                                                        df_linea.at[i,'valor_insta'])
    
# Costos asociados con los materiales y con la excavacion (calculado por proporcion a la altura)
# Material de cama
    df_linea.at[i,'costo']+=mat_are*(mat_cama/df_linea.at[i,'h_barra'])* df_linea.at[i,'vol_exc'] 
# Material de reemplazo
    df_linea.at[i,'costo']+=mat_sel*(df_linea.at[i,'vol_exc']*
                            (df_linea.at[i,'h_barra']-mat_cama)/df_linea.at[i,'h_barra']
                            -df_linea.at[i,'d_ext']**2*math.pi/4*df_linea.at[i,'L'])
# Costos de disposicion del material sobrtante de excavacion
    df_linea.at[i,'costo']+=mat_retiro*d_disposicion*((mat_cama/df_linea.at[i,'h_barra'])* df_linea.at[i,'vol_exc']+
                            df_linea.at[i,'L']*df_linea.at[i,'d_ext']**2*np.pi/4)
    
# Costos excavacion por rango de profundidad
    if df_linea.at[i,'h_barra']<2:
        df_linea.at[i,'costo']+=exc_0_2*df_linea.at[i,'vol_exc']
    elif df_linea.at[i,'h_barra']>=2 and df_linea.at[i,'h_barra']<=5:
        df_linea.at[i,'costo']+=exc_0_2*df_linea.at[i,'vol_exc']*(2/df_linea.at[i,'h_barra'])
        df_linea.at[i,'costo']+=exc_2_5*df_linea.at[i,'vol_exc']*((df_linea.at[i,'h_barra']-2)/df_linea.at[i,'h_barra'])
    elif df_linea.at[i,'h_barra']>5 and df_linea.at[i,'h_barra']<=7:
        df_linea.at[i,'costo']+=exc_0_2*df_linea.at[i,'vol_exc']*(2/df_linea.at[i,'h_barra'])
        df_linea.at[i,'costo']+=exc_2_5*df_linea.at[i,'vol_exc']*(3/df_linea.at[i,'h_barra'])
        df_linea.at[i,'costo']+=exc_5_7*df_linea.at[i,'vol_exc']*((df_linea.at[i,'h_barra']-5)/df_linea.at[i,'h_barra'])
    elif df_linea.at[i,'h_barra']>7:
        df_linea.at[i,'costo']+=exc_0_2*df_linea.at[i,'vol_exc']*(2/df_linea.at[i,'h_barra'])
        df_linea.at[i,'costo']+=exc_2_5*df_linea.at[i,'vol_exc']*(3/df_linea.at[i,'h_barra'])
        df_linea.at[i,'costo']+=exc_5_7*df_linea.at[i,'vol_exc']*(2/df_linea.at[i,'h_barra'])
        df_linea.at[i,'costo']+=exc_7*df_linea.at[i,'vol_exc']*((df_linea.at[i,'h_barra']-7)/df_linea.at[i,'h_barra'])

# Costos entibados por rango de profundidad        
    if df_linea.at[i,'h_barra']<=3:
        df_linea.at[i,'costo']+=ent_0_3*2*df_linea.at[i,'h_barra']
    elif df_linea.at[i,'h_barra']>3 and df_linea.at[i,'h_barra']<=4.8:
        df_linea.at[i,'costo']+=ent_3_48*2*df_linea.at[i,'h_barra']
    elif df_linea.at[i,'h_barra']>5 and df_linea.at[i,'h_barra']<=7.2:
        df_linea.at[i,'costo']+=ent_48_72*2*df_linea.at[i,'h_barra']
    elif df_linea.at[i,'h_barra']>7.2:
        df_linea.at[i,'costo']+=ent_72*2*df_linea.at[i,'h_barra']
    df_linea.at[i,'costo_mat']=df_linea.at[i,'costo']-df_linea.at[i,'costo_tub']
        
# Funcion de costos por la comision de regulación de agua potable y saneamiento básico CRA
    df_linea.at[i,'fc_CRA']=1.5302*(9579.31*(df_linea.at[i,'d']*1000)**0.5737*df_linea.at[i,'L']+
                                    1163.77*df_linea.at[i,'vol_exc']**1.31)

# Funcion de costos propia obtenida mediante el ajuste a una funcion pontencial del tipo F=A.X^B
    df_linea.at[i,'fc_prop']=(df_linea.at[i,'L']*1004861.4272*df_linea.at[i,'d']**1.7928+
                                43644.8004*df_linea.at[i,'vol_exc']**0.9583)
    return df_linea


## Funcion iterativa de tuberias
def procesar(): 
# Barra de progreso
    final = len(df)*len(tubos)
    barra_progreso = crear_barra_progreso(final)
    ij=0
# Itera tuberias de la red    
    for i, row in df.iterrows():
# Itera diametros disponibles
        for j, row in tubos.iterrows():
            ij+=1
            actualiza_barra_progreso(barra_progreso, ij, final)
            global n
            global d
            global Q
            global tao
            global d_minimo
            global sobrependiente
            global d_sobrependiente
            valido=1
            df_s_minima=df.iloc[[i]]
            n=df_s_minima.at[i,'n']=tubos.at[j,'n_mann']
            d=df_s_minima.at[i,'d']=tubos.at[j,'d_interno']
            df_s_minima.at[i,'d_pz_fin']=tubos.at[j,'d_pozo']
            tao=df_s_minima.at[i,'tao']=tubos.at[j,'tao']
            df_s_minima.at[i,'d_pz_fin']=tubos.at[j,'d_pozo']
            df_s_minima.at[i,'d_ext']=tubos.at[j,'d_externo']
            df_s_minima.at[i,'sa_zanja']=tubos.at[j,'a_zanja']
            df_s_minima.at[i,'valor_ml']=tubos.at[j,'valor_ml']
            df_s_minima.at[i,'valor_insta']=tubos.at[j,'valor_insta']
            Q=df_s_minima.at[i,'Q']/1000            

# Calculo de la pendiente minima de la tuberia que cumple los requerimientos minimos mediante scipy.optimize         
            df_s_minima.at[i,'ang']=float(root(func,math.pi).x) 

# Verifica la validez de la tuberia - Valida si no existe pendiente para la combinacion de caudal y diametro
            if (df_s_minima.at[i,'ang']>2*np.pi or 
                df_s_minima.at[i,'ang']<0.0 or 
                df_s_minima.at[i,'d']<d_minimo or 
                df_s_minima.at[i,'d']<df_s_minima.at[i,'d_obg']):
                valido=0
            else:
                df_s_minima.at[i,'S_min']=tao/(rho*g*(d*(1-math.sin(df_s_minima.at[i,'ang'])
                                            /df_s_minima.at[i,'ang'])/4))
                try:
                    df_s_minima=calcular_linea1(i,df_s_minima)
                except:
                      print("No hay solucion para la combinacion de Q,d,S..... supero los diametros disponibles")
# Nota: Este mensaje no deberia visualizarse, de suceder require diametros mas grandes adicionales.
# Al validar la combinacion D,d,S. De acuerdo a la norma requeriria calculo de flujo no permanante con otro software.
                        
# Evita flujos con Froude cercano al critico en el rango (fr_sc, fr_cr) definidos en setup.csv
# cambiando la pendiente y recalculando hasta que el numero de Froude sea superior a fr_cr
                while df_s_minima.at[i,'F']>fr_sc and df_s_minima.at[i,'F']<fr_cr: 
                    sobrependiente+=delta_S
                    df_s_minima=calcular_linea1(i,df_s_minima)
                sobrependiente=0.0  

# Verifica la relacion tirante/diametro                
                if df_s_minima.at[i,'Y_d']>tubos.at[j,'y_D']:
                    valido=0
# Verifica si el costo calculado para el diametro(n) es meor que el costo calculado para el diametro(n-1)
                if float(df.iloc[[i]]['costo'])>df_s_minima.at[i,'costo'] and valido==1:
                    df.iloc[[i]]=df_s_minima 
# Obliga un recubrimiento minimo para las tuberias dependientes        
        for k in range(i+1, len(df), 1):
            if df.at[k,'pz_ini']==df.at[i,'pz_fin']:
                df.at[k,'d_obg']=max(df.at[i,'d'],df.at[k,'d_obg'])
                df.at[k,'obg_ini']=max(df.at[i,'obg_sig'],df.at[k,'obg_ini'])
                df.at[k,'d_pz_ini']=max(df.at[i,'d_pz_fin'],df.at[k,'d_pz_ini'])
# En el caso de tuberia pluvial requiere recalcular
        recalcular()
    
# Caudal propio
    df['Q_propio']=df['Q']
    for i, row in df.iterrows():    
        for k in range(i+1, len(df), 1):
            if df.at[k,'pz_ini']==df.at[i,'pz_fin']:
                df.at[k,'Q_propio']=df.at[k,'Q_propio']-df.at[i,'Q']

## Halla la cota batea de los pozos (m.s.n.m) de acuerdo a la batea mas baja de las tuberias que conectan a el pozo
    global pozos
    pozos=df.loc[:,"pz_ini"]
    pozos=pozos.append(df.loc[:,"pz_fin"])
    pozos=pd.DataFrame(pozos).drop_duplicates().rename(columns={0: "pozo"}).reset_index(drop=True)
    pozos['batea'] = 1000000.0
    pozos['Q_propio'] = 0.0
    pozos['Coord_X'] = 0.0
    pozos['Coord_Y'] = 0.0
    pozos['Coord_Z'] = 0.0
    for i, row in pozos.iterrows():
        for j, row in df.iterrows():
            if pozos.at[i,'pozo']==df.at[j,'pz_ini']:
                pozos.at[i,'batea']=min(df.at[j,'bat_ini'],pozos.at[i,'batea'])
            if pozos.at[i,'pozo']==df.at[j,'pz_fin']:
                pozos.at[i,'batea']=min(df.at[j,'bat_fin'],pozos.at[i,'batea'])

    for i, row in pozos.iterrows():
        for j, row in df.iterrows():
            if pozos.at[i,'pozo']==df.at[j,'pz_fin']:
                df.at[j,'pz_fin_bat']=min(df.at[j,'pz_fin_bat'],pozos.at[i,'batea']) 
            if pozos.at[i,'pozo']==df.at[j,'pz_ini']:
                df.at[j,'pz_ini_bat']=min(df.at[j,'pz_ini_bat'],pozos.at[i,'batea'])
# Para exportar a SWMM y SewerGems
                pozos.at[i,'Q_propio']=df.at[j,'Q_propio']
                pozos.at[i,'Coord_X'] = df.at[j,'x_ini']
                pozos.at[i,'Coord_Y'] = df.at[j,'y_ini']
                pozos.at[i,'Coord_Z'] = df.at[j,'z_ini']
    pozos.at[i,'Coord_X'] = df.at[j,'x_fin']
    pozos.at[i,'Coord_Y'] = df.at[j,'y_fin']            
    pozos.at[i,'Coord_Z'] = df.at[j,'z_fin']  
    print("Proyecto ejecutado")



def exportar(): 
    global files_path
## Exporta la red calculada
# csv con la informacion de los pozos
    pozos.to_csv(os.path.join(files_path, 'pozos.csv')) 
# csv con la red calculada
    df.to_csv(os.path.join(files_path, 'red_calculada.csv'))
    
## Exporta inp para el uso en SewerGems y SWMM    
    f=open(os.path.join(files_path, 'red.inp'),"w")
# Titulo    
    f.write("[TITLE]\n")
    f.write("Modelacion\n")
    f.write("\n")
    
# Opciones    
    f.write("[OPTIONS]\n")
    f.write(";;Option Value\n")
    f.write("FLOW_UNITS LPS\n")
    f.write("INFILTRATION HORTON\n")
    f.write("FLOW_ROUTING DYNWAVE\n")
    f.write("LINK_OFFSETS DEPTH\n")
    f.write("MIN_SLOPE 0\n")
    f.write("ALLOW_PONDING NO\n")
    f.write("SKIP_STEADY_STATE NO\n")
    f.write("START_DATE 01/01/2022\n")
    f.write("START_TIME 23:00:02\n")
    f.write("REPORT_START_DATE 01/01/2022\n")
    f.write("REPORT_START_TIME 23:00:02\n")
    f.write("END_DATE 01/02/2022\n")
    f.write("END_TIME 00:00:02\n")
    f.write("SWEEP_START 01/01\n")
    f.write("SWEEP_END 12/31\n")
    f.write("DRY_DAYS 0\n")
    f.write("REPORT_STEP 1:00:00\n")
    f.write("WET_STEP 0:05:00\n")
    f.write("DRY_STEP 1:00:00\n")
    f.write("ROUTING_STEP 0:00:05\n") 
    f.write("RULE_STEP 00:00:00\n")
    f.write("INERTIAL_DAMPING PARTIAL\n")
    f.write("NORMAL_FLOW_LIMITED BOTH\n")
    f.write("FORCE_MAIN_EQUATION D-W\n")
    f.write("VARIABLE_STEP 0.75\n")
    f.write("LENGTHENING_STEP 0\n")
    f.write("MIN_SURFAREA 0\n")
    f.write("MAX_TRIALS 0\n")
    f.write("HEAD_TOLERANCE 0\n")
    f.write("SYS_FLOW_TOL 5\n")
    f.write("LAT_FLOW_TOL 5\n")
    f.write("MINIMUM_STEP 0.5\n")
    f.write("THREADS 1\n")
    f.write("\n")    
    
# Evaporacion    
    f.write("[EVAPORATION]\n")
    f.write(";;DataSource Parameters\n")
    f.write("CONSTANT 0\n")
    f.write("DRY_ONLY NO\n")
    f.write("\n") 

# Nodos
    f.write("[JUNCTIONS]\n")
    f.write(";;Name Elevation MaxDepth InitDepth SurDepth Aponded\n")
    for i, row in pozos.iterrows():
        if i<len(pozos.index)-1:
            f.write(str(pozos.at[i,'pozo'])+' '+
                    "{:.4f}".format(pozos.at[i,'batea'])+' '+
                    "{:.4f}".format(pozos.at[i,'Coord_Z']-pozos.at[i,'batea'])+' '
                    '0 0 0'+"\n")
    f.write("\n")     
    
# Descargas
    f.write("[OUTFALLS]\n")
    f.write(";;Name Elevation Type StageData Gated RouteTo\n")
    f.write(str(pozos.at[i,'pozo'])+' '+
            "{:.4f}".format(pozos.at[i,'batea'])+' '+
            'FREE NO'+"\n")
    f.write("\n")      

# Conexion de Tuberias
    f.write("[CONDUITS]\n")
    f.write(";;Name FromNode ToNode Length Roughness InOffset OutOffset InitFlow MaxFlow\n")
    for j, row in df.iterrows():
        f.write(str(df.at[j,'idd'])+' '+
                str(df.at[j,'pz_ini'])+' '+
                str(df.at[j,'pz_fin'])+' '+
                "{:.4f}".format(df.at[j,'L'])+' '+
                "{:.4f}".format(df.at[j,'n'])+' '+
                "{:.4f}".format(df.at[j,'bat_ini']-df.at[j,'pz_ini_bat'])+' '+
                "{:.4f}".format(df.at[j,'bat_fin']-df.at[j,'pz_fin_bat'])+' '+
                '0 0'+"\n")    
    f.write("\n")

# Seccion de Tuberias
    f.write("[XSECTIONS]\n")
    f.write(";;Link Shape Geom1 Geom2 Geom3 Geom4 Barrels Culvert\n")
    for j, row in df.iterrows():
        f.write(str(df.at[j,'idd'])+' CIRCULAR '+
                "{:.4f}".format(df.at[j,'d'])+' '+
                '0 0 0 1'+"\n")       
    f.write("\n") 

# Caudales
    f.write("[DWF]\n")
    f.write(";;Node Constituent Baseline Patterns\n")
    for i, row in pozos.iterrows():
        f.write(str(pozos.at[i,'pozo'])+' FLOW '+
                "{:.4f}".format(pozos.at[i,'Q_propio'])+' '+
                '"" "" ""'+"\n")    
    f.write("\n") 

# Reportes
    f.write("[REPORT]\n")
    f.write(";;Reporting Options\n")
    f.write("SUBCATCHMENTS ALL\n")
    f.write("NODES ALL\n")
    f.write("LINKS ALL\n")
    f.write("\n") 

# Tags
    f.write("[TAGS]\n")
    f.write("\n")

# Mapa
    f.write("[MAP]\n")
    f.write("Units None\n")
    f.write("\n") 

# Coordenadas de nodos
    f.write("[COORDINATES]\n")
    f.write(";;Nodo X Y\n")
    for i, row in pozos.iterrows():
        f.write(str(pozos.at[i,'pozo'])+' '+
                "{:.4f}".format(pozos.at[i,'Coord_X'])+' '+
                "{:.4f}".format(pozos.at[i,'Coord_Y'])+"\n")    
    f.write("\n") 

# Vertices
    f.write("[VERTICES]\n")
    f.write(";;Link X Y\n")
    f.write("\n") 
    f.close()

    print("Archivo red.inp exportado para el uso en SWMM y SewerGems")
    
def visualiza(): 
    global df
    global pozos
    QgsProject.instance().clear()
    layer = QgsVectorLayer("linestring?crs=epsg:3116&field=num", "Tubos", "memory")
    QgsProject.instance().addMapLayer(layer)
    pr = layer.dataProvider()
    for column in df:
        pr.addAttributes([QgsField(column, QVariant.String)])
    layer.updateFields()
    for j, row in df.iterrows():
        fet = QgsFeature(layer.fields())
        for column in df:
            fet.setAttribute(column, str(df.at[j,column]))
        fet.setGeometry(QgsGeometry.fromPolyline([QgsPoint(int(df.at[j,'x_ini']), int(df.at[j,'y_ini'])), QgsPoint(int(df.at[j,'x_fin']), int(df.at[j,'y_fin']))]))
        (res, outFeats) = layer.dataProvider().addFeatures([fet])
    layer.updateExtents()
    
    layer = QgsVectorLayer("point?crs=epsg:3116&field=pozo", "Pozos", "memory")
    QgsProject.instance().addMapLayer(layer)
    pr = layer.dataProvider()
    for column in pozos:
        pr.addAttributes([QgsField(column, QVariant.String)])
    layer.updateFields()
    for j, row in pozos.iterrows():
        fet = QgsFeature(layer.fields())
        for column in pozos:
            fet.setAttribute(column, str(pozos.at[j,column]))
        fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(int(pozos.at[j,'Coord_X']),int(pozos.at[j,'Coord_Y']))))
        (res, outFeats) = layer.dataProvider().addFeatures([fet])
    layer.updateExtents()    
    
    layer_settings  = QgsPalLayerSettings()
    text_format = QgsTextFormat()

    text_format.setFont(QFont("Arial", 10))
    text_format.setSize(12)

    buffer_settings = QgsTextBufferSettings()
    buffer_settings.setEnabled(True)
    buffer_settings.setSize(1)
    buffer_settings.setColor(QColor("white"))

    text_format.setBuffer(buffer_settings)
    layer_settings.setFormat(text_format)

    layer_settings.fieldName = "pozo"
    layer_settings.placement = 2

    layer_settings.enabled = True

    layer_settings = QgsVectorLayerSimpleLabeling(layer_settings)
    layer.setLabelsEnabled(True)
    layer.setLabeling(layer_settings)
    layer.triggerRepaint()

def ver_perfiles():
    global df
    global escala
    k=0
    for i in range(0, len(df['red'].unique()), 1):
        df2=df.query('red == ' + str(i+1))
        layer = QgsVectorLayer("linestring?crs=epsg:3116&field=num", "Perfil" + str(i+1), "memory")
        QgsProject.instance().addMapLayer(layer)
        pr = layer.dataProvider()
        for j, row in df2.iterrows():
        
        
            fet = QgsFeature(layer.fields())
            fet.setGeometry(QgsGeometry.fromPolyline([QgsPoint(float(df2.at[j,'absc']-df2.at[j,'L_XY_tubo']-df2.at[j,'d_pz_ini']-df2.at[j,'d_pz_fin']/2), escala*float(df2.at[j,'z_ini'])), 
                                                      QgsPoint(float(df2.at[j,'absc']-df2.at[j,'L_XY_tubo']-df2.at[j,'d_pz_fin']/2), escala*float(df2.at[j,'z_ini']))]))
            (res, outFeats) = layer.dataProvider().addFeatures([fet])     
            
            fet = QgsFeature(layer.fields())
            fet.setGeometry(QgsGeometry.fromPolyline([QgsPoint(float(df2.at[j,'absc']-df2.at[j,'L_XY_tubo']-df2.at[j,'d_pz_ini']-df2.at[j,'d_pz_fin']/2), escala*float(df2.at[j,'pz_ini_bat'])), 
                                                      QgsPoint(float(df2.at[j,'absc']-df2.at[j,'L_XY_tubo']-df2.at[j,'d_pz_fin']/2), escala*float(df2.at[j,'pz_ini_bat']))]))
            (res, outFeats) = layer.dataProvider().addFeatures([fet]) 

            fet = QgsFeature(layer.fields())
            fet.setAttribute("num", df2.at[j,'pz_ini'])
            fet.setGeometry(QgsGeometry.fromPolyline([QgsPoint(float(df2.at[j,'absc']-df2.at[j,'L_XY_tubo']-df2.at[j,'d_pz_ini']-df2.at[j,'d_pz_fin']/2), escala*float(df2.at[j,'z_ini'])), 
                                                      QgsPoint(float(df2.at[j,'absc']-df2.at[j,'L_XY_tubo']-df2.at[j,'d_pz_ini']-df2.at[j,'d_pz_fin']/2), escala*float(df2.at[j,'pz_ini_bat']))]))
            (res, outFeats) = layer.dataProvider().addFeatures([fet])
            fet = QgsFeature(layer.fields())            
            fet.setGeometry(QgsGeometry.fromPolyline([QgsPoint(float(df2.at[j,'absc']-df2.at[j,'L_XY_tubo']-df2.at[j,'d_pz_fin']/2), escala*float(df2.at[j,'z_ini'])), 
                                                      QgsPoint(float(df2.at[j,'absc']-df2.at[j,'L_XY_tubo']-df2.at[j,'d_pz_fin']/2), escala*float(df2.at[j,'pz_ini_bat']))]))
            (res, outFeats) = layer.dataProvider().addFeatures([fet]) 

            fet.setGeometry(QgsGeometry.fromPolyline([QgsPoint(float(df2.at[j,'absc']-df2.at[j,'L_XY_tubo']-df2.at[j,'d_pz_ini']/2), escala*float(df2.at[j,'bat_ini'])), 
                                                      QgsPoint(float(df2.at[j,'absc']-df2.at[j,'d_pz_ini']/2), escala*float(df2.at[j,'bat_fin']))]))
            (res, outFeats) = layer.dataProvider().addFeatures([fet])
            fet.setGeometry(QgsGeometry.fromPolyline([QgsPoint(float(df2.at[j,'absc']-df2.at[j,'L_XY_tubo']-df2.at[j,'d_pz_ini']/2), escala*float(df2.at[j,'cla_ini'])), 
                                                      QgsPoint(float(df2.at[j,'absc']-df2.at[j,'d_pz_ini']/2), escala*float(df2.at[j,'cla_fin']))]))
            (res, outFeats) = layer.dataProvider().addFeatures([fet])
            fet.setGeometry(QgsGeometry.fromPolyline([QgsPoint(float(df2.at[j,'absc']-df2.at[j,'L_XY_tubo']-df2.at[j,'d_pz_ini']/2), escala*float(df2.at[j,'z_ini'])), 
                                                      QgsPoint(float(df2.at[j,'absc']-df2.at[j,'d_pz_fin']/2), escala*float(df2.at[j,'z_fin']))]))
            (res, outFeats) = layer.dataProvider().addFeatures([fet])
            
        layer.updateExtents()

        layer_settings  = QgsPalLayerSettings()
        layer_settings.fieldName = "num"
        layer_settings.placement = 2
        layer_settings.enabled = True
        layer_settings = QgsVectorLayerSimpleLabeling(layer_settings)
        layer.setLabelsEnabled(True)
        layer.setLabeling(layer_settings)
        layer.triggerRepaint()    
    
    print("Perfiles generados")

def borrar_corrida():
    global files_path
    if os.path.isfile(os.path.join(files_path, 'red_calculada.csv')):
        os.remove(os.path.join(files_path, 'red_calculada.csv'))
    if os.path.isfile(os.path.join(files_path, 'pozos.csv')):
        os.remove(os.path.join(files_path, 'pozos.csv')) 
    if os.path.isfile(os.path.join(files_path, 'red_calculada_SWMM.csv')):
        os.remove(os.path.join(files_path, 'red_calculada_SWMM.csv'))
    if os.path.isfile(os.path.join(files_path, 'pozos_SWMM.csv')):
        os.remove(os.path.join(files_path, 'pozos_SWMM.csv')) 
    if os.path.isfile(os.path.join(files_path, 'red.inp')):
        os.remove(os.path.join(files_path, 'red.inp'))
    if os.path.isfile(os.path.join(files_path, 'red.dat')):
        os.remove(os.path.join(files_path, 'red.dat'))
    if os.path.isfile(os.path.join(files_path, 'red.rpt')):
        os.remove(os.path.join(files_path, 'red.rpt'))        
    print("Corrida previa eliminada")

def simula_SWMM():
    global df
    global pozos  
    global files_path
    df_SWMM=df

    pozos_SWMM=pozos
    archivoINP=os.path.join(files_path, 'red.inp')
    archivoRPT=os.path.join(files_path, 'red.rpt')
    archivoDAT=os.path.join(files_path, 'red.dat')

    from swmm5.swmm5tools import SWMM5Simulation
    from swmm5 import swmm5 as sw
    st=SWMM5Simulation(archivoINP)

#Resultados
    pozos_SWMM['SWMM_WS']=0.0
    pozos_SWMM['SWMM_H']=0.0
    pozos_SWMM['SWMM_Q']=0.0
    pozos_SWMM['SWMM_Qt']=0.0     
    
    df_SWMM['SWMM_Q']=0.0
    df_SWMM['SWMM_Y']=0.0
    df_SWMM['SWMM_V']=0.0
    
    for i, row in pozos_SWMM.iterrows():
        for j in range(0, int(st.SWMM_Nnodes), 1):
            if pozos_SWMM.at[i,'pozo']==st.Node()[j]:
#0 Depth of water above invert (ft or m) - Variable: SWMM_WS
                pozos_SWMM.at[i,'SWMM_WS']=list(st.Results('NODE',st.Node()[j], 0))[0]
#1 Hydraulic head (ft or m) - Variable: SWMM_H                
                pozos_SWMM.at[i,'SWMM_H']=list(st.Results('NODE',st.Node()[j], 1))[0]
#3 Lateral inflow (flow units) - Variable: SWMM_Q                
                pozos_SWMM.at[i,'SWMM_Q']=list(st.Results('NODE',st.Node()[j], 3))[0]
#4 Total inflow (lateral + upstream) (flow units) - Variable: SWMM_Qt                
                pozos_SWMM.at[i,'SWMM_Qt']=list(st.Results('NODE',st.Node()[j], 4))[0]

    for i, row in df_SWMM.iterrows():
        for j in range(0, int(st.SWMM_Nlinks), 1):
            if df_SWMM.at[i,'idd']==st.Link()[j]:
#0 Flow rate (flow units) - Variable: SWMM_Q            
                df_SWMM.at[i,'SWMM_Q']=list(st.Results('LINK',st.Link()[j], 0))[0]
#1 Flow depth (ft or m) - Variable: SWMM_Y                
                df_SWMM.at[i,'SWMM_Y']=list(st.Results('LINK',st.Link()[j], 1))[0]
#2 Flow velocity (ft/s or m/s) - Variable: SWMM_V                
                df_SWMM.at[i,'SWMM_V']=list(st.Results('LINK',st.Link()[j], 2))[0]
  
#Genera archivo de reporte .rpt
    ret=sw.RunSwmmDll(archivoINP,archivoRPT,archivoDAT)

## Exporta la red calculada con informacion de modelacion con SWMM
# csv con la informacion de los pozos
    pozos_SWMM.to_csv(os.path.join(files_path, 'pozos_SWMM.csv'))
# csv con la red calculada
    df_SWMM.to_csv(os.path.join(files_path, 'red_calculada_SWMM.csv')) 
    print("Simulacion en SWMM ejecutada")

class IniciarWidget(DialogType, DialogBase):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.setWindowIcon(QIcon(os.path.join(plugin_path, 'data\\img','icon2.png')))
        self.mQgsFileWidget.setDefaultRoot(os.path.join(plugin_path,'data\\ejemplos'))
        app=None
        app = wx.App(False) 
        self.setGeometry(wx.GetDisplaySize()[0]-350-20, int(wx.GetDisplaySize()[1]/2-200), 350, 400) # left, top, width, height
        
        self.toolButton_1.setIcon(QIcon(os.path.join(plugin_path, 'data\\img','help.png')))
        self.toolButton_2.setIcon(QIcon(os.path.join(plugin_path, 'data\\img','help.png')))
        self.toolButton_3.setIcon(QIcon(os.path.join(plugin_path, 'data\\img','help.png')))
        self.toolButton_4.setIcon(QIcon(os.path.join(plugin_path, 'data\\img','help.png')))
        self.toolButton_5.setIcon(QIcon(os.path.join(plugin_path, 'data\\img','help.png')))
        self.toolButton_6.setIcon(QIcon(os.path.join(plugin_path, 'data\\img','help.png')))
        
# Signals        
        self.pushButton_abrir_proyecto.clicked.connect(self.cargar)
        self.pushButton_borrar_corrida.clicked.connect(self.borrar)
        self.pushButton_perfil.clicked.connect(self.ver_perfil)
        self.pushButton_exporta.clicked.connect(self.exporta)
        self.pushButton_SWMM.clicked.connect(self.corre_SWMM)
        
        self.toolButton_1.clicked.connect(self.ayuda1)
        self.toolButton_2.clicked.connect(self.ayuda2)
        self.toolButton_3.clicked.connect(self.ayuda3)
        self.toolButton_4.clicked.connect(self.ayuda4)
        self.toolButton_5.clicked.connect(self.ayuda5)
        self.toolButton_6.clicked.connect(self.ayuda6)
        
    def cargar(self):
        global df
        global escala 
        global files_path        
        files_path= self.mQgsFileWidget.filePath() 
        global plugin_path
        print("\nProyecto cargado")
        if (os.path.isfile(os.path.join(files_path, 'red_calculada.csv')) and 
          os.path.isfile(os.path.join(files_path, 'pozos.csv')) and 
          os.path.isfile(os.path.join(files_path, 'red.inp')) and 
          os.path.isfile(os.path.join(files_path, 'red.rpt'))):
            carga_datos_existentes()
        else:
            carga_datos()
            inicializar()
            recalcular()
            procesar()            
        visualiza()

    def borrar(self):
        global files_path        
        files_path= self.mQgsFileWidget.filePath()     
        borrar_corrida()

    def ver_perfil(self):
        ver_perfiles()

    def exporta(self):
        exportar()

    def corre_SWMM(self):
        try:
            simula_SWMM()
        except:
            print("Paquete SWMM5 No instalado")
            
    def ayuda1(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle("Ayuda")
        msg.setText("Se tienen 5 directorios cada uno con la definición de la topología en planta, cotas rasantes de los nodos, condiciones de frontera específicas para la red y otras variables de inicialización de una red de alcantarillado. La selección de alguno de los directorios disponibles, define el directorio de trabajo donde se tomará la información base, se guardarán las ejecuciones del programa y se exportará la red que podrá ser usada en SWMM o en SewerGems.")
        msg.exec_()          
            
    def ayuda2(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle("Ayuda")
        msg.setText("Si el usuario previamente había ejecutado el diseño de las redes del directorio seleccionado, podrá borrar los archivos generados y hacer una corrida completamente de cero, de lo contrario el software usa la información de la corrida previa.")
        msg.exec_()  

    def ayuda3(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle("Ayuda")
        msg.setText("Ejecuta de cero una red o carga una red previamente modelada. Aparecerá una barra de progreso en el caso de una corrida nueva.")
        msg.exec_()  
        
    def ayuda4(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle("Ayuda")
        msg.setText("Se generará perfiles de la red con una deformación H/V de 1:10")
        msg.exec_()  

    def ayuda5(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle("Ayuda")
        msg.setText("Exporta un archivo “red.inp”, el cual puede ser importado desde SWMM o SewerGems. Contiene la geometría en planta y en perfil de la red, condiciones de frontera y otra información requerida.")
        msg.exec_()  
        
    def ayuda6(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle("Ayuda")
        msg.setText("Ejecuta una simulación en SWMM mediante el complemento SWMM5 para QGIS.")
        msg.exec_()  
               
class Formulario:
    def __init__(self, iface):
        self.iface = iface

    def initGui(self):
        self.action = QAction(u'Iniciar/Cargar diseño de red de alcantarillado', self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.action.setIcon(QIcon(os.path.join(plugin_path, 'data\\img','icon2.png')))
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        print("Plugin recargado")
        self.iface.removeToolBarIcon(self.action)
        del self.action

    def run(self):
        self.dlg = IniciarWidget()
        self.dlg.show() 
        print("Inicializando")