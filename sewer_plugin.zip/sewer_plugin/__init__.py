from .sewer_plugin import Formulario

def classFactory(iface):
    return Formulario(iface)